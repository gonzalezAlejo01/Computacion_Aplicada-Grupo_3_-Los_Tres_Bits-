ls
bash /opt/scripts/backup_full.sh archivos_consigna
bash /opt/scripts/backup_full.sh /archivos_consigna
bash /opt/scripts/backup_full.sh ./archivos_consigna
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh ./archivos_consigna
bash /opt/scripts/backup_full.sh -help
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh ./archivos_consigna
bash /opt/scripts/backup_full.sh archivos_consigna
nano /opt/scripts/backup_full.sh 
tar -czf /mnt/backup_dir/ -C 
cat /etc/apt/sources.list
nano /etc/apt/sources.list
bash /opt/scripts/backup_full.sh archivos_consigna
cd ..
cd ..
cd /mnt/www_dir/
ls
 nano /etc/apache2/apache2.conf
 nano /etc/apache2/sites-available/000-default.conf 
cat /etc/network/interfaces
lsblk
fdisk sdc
fdisk /dev/sdc
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/
cd ..
cd ..
bash /opt/scripts/backup_full.sh /root/archivos_consigna/
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/
bash /opt/scripts/backup_full.sh /root/archivos_consigna
cd /mnt/backup_dir/
ls
rm backupear_bkp_20261026.tar.gz 
rm _bkp_20261026.tar.gz 
bash /opt/scripts/backup_full.sh /root/archivos_consigna
ls
tar -xvf archivos_consigna_bkp_20261026.tar.gz
ls
cd root/
ls
cd archivos_consigna/
ls
cd ..
cd ..
rm -rf root/
rf archivos_consigna_bkp_20261026.tar.gz 
rm backup.tar.gz 
rm archivos_consigna_bkp_20261026.tar.gz 
nano /opt/scripts/backup_full.sh 

nano /opt/scripts/backup_full.sh 
ls
cd ..
cd ..
bash opt/scripts/backup_full.sh root/archivos_consigna/
ls /mnt/backup_dir/
tar -xvf /mnt/backup_dir/archivos_consigna_bkp_20261026.tar.gz
tar -xvf /mnt/backup_dir/archivos_consigna_bkp_20261028.tar.gz
ls
ls /mnt/backup_dir/
ls
cd root
ls
cd archivos_consigna/
ls
cd ..
cd ..
cd root
ls
mkdir tests_backups
cd tests_backups/
tar -xvf /mnt/backup_dir/archivos_consigna_bkp_20261028.tar.gz
ls
cd root/
cd archivos_consigna/
ls
c d..
cd ..
cd ..
rm -rf root/
ls
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh ../archivos_consigna/ 
bash /opt/scripts/backup_full.sh ../archivos_consigna/ .
bash /opt/scripts/backup_full.sh ../archivos_consigna/.
bash /opt/scripts/backup_full.sh ../archivos_consigna
ls
ls
ls /mnt/backup_dir/
bash /opt/scripts/backup_full.sh ../archivos_consigna/.
ls /mnt/backup_dir/
bash /opt/scripts/backup_full.sh ../archivos_consigna/.
bash /opt/scripts/backup_full.sh ../archivos_consigna/
ls /mnt/backup_dir/
bash /opt/scripts/backup_full.sh /root/archivos_consigna/
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/
bash /opt/scripts/backup_full.sh /root/archivos_consigna
bash /opt/scripts/backup_full.sh /root/archivos_consigna/
clear
bash /opt/scripts/backup_full.sh /root/archivos_consigna/
bash /opt/scripts/backup_full.sh /root/archivos_consigna/
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/
rm /mnt/backup_dir/archivos_consigna_bkp_20261028.tar.gz 
rm /mnt/backup_dir/._bkp_20261028.tar.gz 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/
tar -xzf /mnt/backup_dir/archivos_consigna_bkp_20261028.tar.gz 
ls
ls
cd ..
ls
cd ..
ls
cd ..
tar -xvf /mnt/backup_dir/archivos_consigna_bkp_20261028.tar.gz -C root/tests_backups/
cd root/tests_backups/
ls
rm db.sql 
rm index.php 
tar -xvf /mnt/backup_dir/archivos_consigna_bkp_20261028.tar.gz -C root/tests_backups/
tar -xvf /mnt/backup_dir/archivos_consigna_bkp_20261028.tar.gz -C /root/tests_backups/
ls
nano /opt/scripts/backup_full.sh 
ls /mnt/backup_dir/
rm /mnt/backup_dir/archivos_consigna_bkp_20261028.tar.gz 
ls
rm db.sql 
rm index.php 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/
tar -xvf /mnt/backup_dir/archivos_consigna_bkp_20261028.tar.gz 
ls
cd ..
cd tests_backups/
rm /mnt/backup_dir/archivos_consigna_bkp_20261028.tar.gz 
rm index.php 
rm db.sql 
nano /opt/scripts/backup_full.sh 
mkdir /mnt/backup_dir/asd
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ /asd
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ asd
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ asd
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ asd
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ asd
ls /mnt/backup_dir/
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ asd
rm /mnt/backup_dir/asdarchivos_consigna_bkp_20261028.tar.gz 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ asd
rm /mnt/backup_dir/asdarchivos_consigna_bkp_20261028.tar.gz 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ /asd
rm /mnt/backup_dir//asdarchivos_consigna_bkp_20261028.tar.gz 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ asd/
ls /mnt/backup_dir/
ls /mnt/backup_dir/asd/
rm /mnt/backup_dir/asd/archivos_consigna_bkp_20261028.tar.gz 
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ asd
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ asd
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ asd
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ asd
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ asd
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ asd
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ asd
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ asd
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ asd/
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ /asd/
nano /opt/scripts/backup_full.sh 
ls /mnt/backup_dir/
rm /mnt/backup_dir/asdarchivos_consigna_bkp_20261028.tar.gz 
rm /mnt/backup_dir/asd/archivos_consigna_bkp_20261028.tar.gz 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ /asd/
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ asd/
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ asd
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ a
tar -xvf /mnt/backup_dir/archivos_consigna_bkp_20261028.tar.gz 
ls
rm db.sql 
rm index.php 
tar -xvf /mnt/backup_dir/archivos_consigna_bkp_20261028.tar.gz 
rm db.sql 
rm index.php 
tar -xvf /mnt/backup_dir/asd/archivos_consigna_bkp_20261028.tar.gz 
ls
cd ..
rm -rf tests_backups/
ls
ls backupear/
rm -rf backupear/
rm -rf delete
rm /mnt/backup_dir/archivos_consigna_bkp_20261028.tar.gz 
rm -rf /mnt/backup_dir/asd/
ls /mnt/backup_dir/
cd ..
ls /etc/apt/sources.list
cat /etc/apt/sources.list
nano /opt/scripts/backup_full.sh 
systemctl status cron
clera
clear
cd ..
crontab -e
ls /etc/crontab 
cat /etc/crontab 
cat /etc/cron.d/anacron
cd /etc/cron.d
ls
nano anacron
nano e2scrub_all 
nano php
nano backups
systemctl restart cron
ls /mnt/backup_dir/
bash /opt/scripts/backup_full.sh /var/log
ls /mnt/backup_dir/
rm /mnt/backup_dir/log_bkp_20261028.tar.gz 
nano backups
nano backups
systemctl restart cron
ls /mnt/backup_dir/
nano backups
ls /var/log
nano backups
grep CRON /var/log/syslog | grep backup_full
bash /opt/scripts/backup_full.sh /var/log
cd /root/
mkdir delete
cd delete/
tar -xvf /mnt/backup_dir/log_bkp_20261028.tar.gz 
ls
cd ..
rm -rf delete/
rm /mnt/backup_dir/log_bkp_20261028.tar.gz 
rm /mnt/backup_dir/www_dir_bkp_20261028.tar.gz 
nano /etc/cron.d/backups
ls /mnt/backup_dir/
nano /etc/cron.d/backups
systemctl restart cron
ls /mnt/backup_dir/
grep 'backup_full.sh' /var/log/syslog
nano /etc/cron.d/backups
rm /mnt/backup_dir/www_dir_bkp_20261028.tar.gz 
ls /mnt/backup_dir/lost+found/
ls /mnt/backup_dir
ls -l /mnt/backup_dir/
ls -la /mnt/backup_dir/
ls -a /mnt/backup_dir/
ls /mnt/backup_dir/
nano /etc/cron.d/backups
rm /mnt/backup_dir/www_dir_bkp_20261028.tar.gz 
ls /mnt/backup_dir/
nano /etc/cron.d/backups
cat /tmp/backup-varlog.log 
nano /opt/scripts/backup_full.sh 
nano /etc/cron.d/backups
cat /tmp/backup-varlog.log 
cat /tmp/backup-varlog.log 
ls /mnt/backup_dir/
nano /opt/scripts/backup_full.sh 
nano /etc/cron.d/backups
rm /mnt/backup_dir/www_dir_bkp_20261028.tar.gz 
ls /mnt/backup_dir/
cat /tmp/backup-varlog.log 
rm /tmp/backup-varlog.log 
nano /etc/cron.d/backups
cat /tmp/backup-varlog.log 
cat /tmp/backup-varlog.log 
cat /tmp/backup-varlog.log 
cat /tmp/backup-varlog.log 
nano /opt/scripts/backup_full.sh 
nano /etc/cron.d/backups
ls /mnt/backup_dir/
cat /tmp/backup-varlog.log 
nano /opt/scripts/backup_full.sh 
nano /etc/cron.d/backups
cat /tmp/backup-varlog.log 
nano /etc/cron.d/backups
cat /tmp/backup-varlog.log 
nano /opt/scripts/backup_full.sh 
cat /tmp/backup-varlog.log 
nano /opt/scripts/backup_full.sh 
nano /etc/cron.d/backups
cat /tmp/backup-varlog.log 
nano /etc/cron.d/backups
ls /mnt/backup_dir/
rm /mnt/backup_dir/log_bkp_20261028.tar.gz 
rm /mnt/backup_dir/www_dir_bkp_20261028.tar.gz 
nano /opt/scripts/backup_full.sh 
ls /mnt/backup_dir/
mkdir borrame
cd borrame/
tar -xvf /mnt/backup_dir/log_bkp_20261028.tar.gz 
ls
tar -xvf /mnt/backup_dir/log_bkp_20261028.tar.gz /logs
mkdir /logs
tar -xvf /mnt/backup_dir/log_bkp_20261028.tar.gz /logs
tar -xvf /mnt/backup_dir/log_bkp_20261028.tar.gz ./logs
tar -xvf /mnt/backup_dir/log_bkp_20261028.tar.gz ./logs/
tar -xvf /mnt/backup_dir/log_bkp_20261028.tar.gz -C /logs
ls /l
ls /logs
cd ..
rm -rf borrame/
nano /etc/cron.d/backups
cd ..
cd root
ls
cat /etc/hostname
cat /etc/hosts
ls /root/.ssh/
cat /root/.ssh/authorized_keys 
rm /mnt/backup_dir/archivos_consigna_bkp_20261028.tar.gz 
ip -a
ip a
nano /etc/ssh/sshd_config
ls /var/www/html/
cat /etc/networks 
cat /etc/network/interfaces
systemctl restart network.services
systemctl restart network.services
systemctl restart network.service
systemctl restart networking.service
lsblk
nano /etc/fstab 
nano /etc/apache2/apache2.conf 
nano /etc/apache2/sites-available/default-ssl.conf 
nano /etc/apache2/sites-available/000-default.conf 
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ asdasd
nano /opt/scripts/backup_full.sh 
ls /mnt/backup_dir/
rm /mnt/backup_dir/archivos_consigna_bkp_20261030.tar.gz 
cat /etc/cron.d/backups 
du -sh /var
ls
cd archivos_consigna/
ls
cd ..
ls
mkdir entregables
cd entregables/
tar -czf /root | split -b 90M -d root.tar.gz
tar -czf /root/ | split -b 90M -d root.tar.gz
tar -czf /root | split -b 90M -d root.tar.gz
tar -czf /root | split -b 90M -d "root.tar.gz"
du -sh /root
tar -czvf /root root.tar.gz
nano /opt/scripts/backup_full.sh 
tar -czvf /root -C root.tar.gz .
tar -czf /root root.tar.gz
cd ..
cd ..
cd ..
tar -czf /root root.tar.gz
ls root/
tar -czf root/ root.tar.gz
clear
clear
clear
tar -czf root/ root.tar.gz
tar -czf root.tar.gz /root
ls
rm root.tar.gz 
cd root/entregables/
tar -czf root.tar.gz /root
ls
tar -xvf root.tar.gz /elRoot
mkdir elRoot
tar -xvf root.tar.gz 
ls
ls root
ls
ls elRoot/
ls root
cd root/
ls
cd entregables/
ls
ls
cd ..
ls archivos_consigna/
ls
cd ..
ls
rm -rf root
rm -rf elRoot/
ls
du -sh /etc
tar -czf etc.tar.gz /etc
ls
du -sh /opt
tar -czf opt.tar.gz /opt
ls
du -sh /proc
du -sh /proc
du -sh /proc
tar -czf proc.tar.gz /proc
ls
mkdir copiaProc
cd copiaProc/
cp -a /proc/. /root/entregables/copiaProc/
df -h
ls
cd ..
du -sh /root/entregables/copiaProc/
du -sh /proc
ls
rm -rf copiaProc/
df -h
cd ..
du -sh /root
cd entregables/
ls
du -sh /root/entregables/proc.tar.gz 
tar -czf proc.tar.gz --ignore-failed-read /proc
rm proc.tar.gz 
tar -czf proc.tar.gz --ignore-failed-read /proc 2>/dev/null
rm proc.tar.gz 
tar -czvf proc.tar.gz /proc
rm proc.tar.gz 
ls
tar -czvf proc.tar.gz --ignore-failed-read --exclude="/proc/kcore" /proc
du -dh proc.tar.gz 
du -sh proc.tar.gz 
ls
tar -czvf ww_dir.tar.gz -C /mnt /www_dir/
tar -czvf ww_dir.tar.gz -C /mnt/ /www_dir/
tar -czvf ww_dir.tar.gz -C /mnt/ www_dir/
ls
tar -czvf www_dir.tar.gz -C /mnt/ www_dir/
rm ww_dir.tar.gz 
tar -czvf backup_dir.tar.gz -C /mnt/ backup_dir/
cat /etc/cron.d
cat /etc/cron.d/backups 
tar -czf - /var | split -b 90M - var.tar.gz.-
ls
rm var.tar.gz.-aa 
du -dh /var
du -sh /var
mkdir var
cd var/
tar -czf - /var | split -d -b 90M - var.tar.gz.p
ls
du -sh .
ls
rm var.tar.gz.p00 
tar -czf - /var | split -d -b 20M - var.tar.gz.p
ls
ls /root
ls /root/entregables/
cat /etc/hostname
cat /etc/hosts
cat /etc/apt/sources.list
nano /etc/ssh/sshd_config
asd
cd ..
cd ..
cd ..
cat root/.ssh/authorized_keys 
cat /etc/fstab 
ls /etc/cron.d/
lsblk
ls /mnt
ls /media
crontab -e
nano /etc/network/interfaces
nano /etc/network/interfaces
ls
cd backups/
ls
cd var/
ls
cd ..
cd ..
quit
exit
