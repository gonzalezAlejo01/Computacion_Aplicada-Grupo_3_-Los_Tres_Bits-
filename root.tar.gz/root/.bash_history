 poweroff
 poweroff
poweroff
vi /etc/apt/sources.list
apt update
apt upgrade
restart
shutdown -r
apt install nano
nano /etc/hostname
hostname
hostname TPServer
nano /etc/hosts
ip addr
systemctl restart networking.service 
ip addr
nano /etc/hosts
ip addr
nano /etc/hosts
nano /etc/network/interfaces
systemctl restart networking.service 
ip addr
nano /etc/network/interfaces
apt install openssh-server
mkdir /root/archivos_consigna
nano /etc/ssh/sshd_config
nano /etc/ssh/sshd_config
ip addr
poweroff
ls
quit
exit
ls archivos_consigna/
nano /etc/ssh/sshd_config
systemctl restart ssh
chmod 700 /root/.ssh
cd ..
cd ..
chmod 700 /root/.ssh
cd root
mkdir .ssh
cd .ssh/
touch authorized_keys
ls
cd ..
chmod 700 .ssh
ls -l .ssh
ls -l
ls -la
ls -la .ssh
chmod 600 .ssh/authorized_keys 
nano .ssh/authorized_keys 
systemctl restart ssh
apt install apache2
cp /root/archivos_consigna/extras/index.php /var/www/html/index.php
rm /var/www/index.html
rm /var/www/html/index.html 
cp /root/archivos_consigna/extras/logo.png /var/www/html/logo.png
apt install libapache2-mod-php
apt install mariadb-server mariadb-cliente galera-4 php-mysqli php-pdo
apt install mariadb-server mariadb-client galera-4 php-mysqli php-pdo
mariadb-secure-installation 
mariadb -u root -p < /root/archivos_consigna/extras/db.sql 
mariadb -u root -p
apt install php-mysqli
apt install php-pdo
apt install mariadb-server
apt install mariadb-client
apt install galera 4
apt install galera-4
nano /root/archivos_consigna/extras/db.sql 
mariadb -u root -p
ip addr
ls /var/www/html/
mariadb -u root -p
systemctl restart mariadb
systemctl restart apache2
ip addr
nano /etc/network/interfaces
systemctl restart networking.service 
poweroff
lsblk
fdisk /dev/sdc
lsblk
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
lsblk
blkid
mkdir /mnt/www_dir
mkdir /mnt/backup_dir
mount /dev/sdc1 /mnt/www_dir/
mount /dev/sdc2 /mnt/backup_dir/
lsblk
nano /etc/fstab 
poweroff
ls
cat particion
exit
lsblk
mv /var/www/html/index.php /mnt/www_dir/
ls
ls /var/www/html/
ls /mnt/www_dir/
mv /var/www/html/logo.png 
mv /var/www/html/logo.png /mnt/www_dir/
ls /mnt/www_dir/
nano /etc/apache2/apache2.conf 
nano /etc/apache2/sites-available/000-default.conf 
nano /etc/apache2/apache2.conf 
nano /etc/apache2/sites-available/000-default.conf 
systemctl restart apache2
ls /proc/partitions 
cat /proc/partitions 
cat /proc/partitions > particion
cat particion 
hostname
cat /etc/hostname
cat /etc/hosts
ip addr
nano /etc/network/interfaces
lsblk
ls /mnt/www_dir/
nano /etc/fstab 
restart
shutdown -r
ls /opt
mkdir /opt/scripts
touch /opt/scripts/backup_full.sh
ls /mnt/backup_dir/
cd ..
ls /root
ls /root/archivos_consigna/extras/
cat db.sql
cat /root/archivos_consigna/extras/db.sql
exit
