 poweroff
 poweroff
apt install nano
hostname
nano /etc/hosts
nano /etc/hostname 
nano /etc/apt/sources.list
apt install openssh-server
apt-install apache2
apt install apache2
apt install libapache2-mod-php
apt install mariadb-server mariadb-client galera-4 php-mysqli php-pdo
nano /etc/network/interfaces
systemctl restart networking.service 
nano /etc/ssh/sshd_config
systemctl restart ssh
host
hostname
man hostname
shutdown -r
ls
cd ..
ls
cd root/
ls
touch test
ls
ls
exit
exit
ls
rm test
ls
mkdir archivos_consigna
nano /etc/ssh/sshd_config
systemctl restart ssh
ls -a
mkdir .ssh
chmod 700 .ssh
mv archivos_consigna/clave_privada.txt .ssh/authorized_keys
chmod 600 .ssh/authorized_keys 
systemctl restart ssh
rm .ssh/authorized_keys 
nano /etc/ssh/sshd_config
systemctl restart ssh
nano /etc/ssh/sshd_config
systemctl restart ssh
mv archivos_consigna/extras/index.php /var/www/html/index.php
mv archivos_consigna/extras/logo.png /var/www/html/logo.png
systemctl restart apache2
ip addr
ls /var/www/html/
rm /var/www/html/index.html 
mariadb-secure-installation 
mariadb -u root -p < /root/archivos_consigna/extras/db.sql 
mariadb -u root -p
lsblk
fdisk /dev/sdc
fdisk /dev/sdc
lsblk
mkdir /mnt/www_dir
mkdir /mnt/backup_dir
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
lsblk
mount /dev/sdc1 /mnt/www_dir/
blkid
blkid
mount /dev/sdc2 /mnt/backup_dir/
lsblk
nano /etc/fstab 
umount /mnt/www_dir 
umount /mnt/backup_dir 
lsblk
mount -a
lsblk
mv /var/www/html/index.php /mnt/www_dir/
mv /var/www/html/logo /mnt/www_dir/
mv /var/www/html/logo.png /mnt/www_dir/
ls /mnt/www_dir/
nano /etc/apache2/apache2.conf 
nano /etc/apache2/sites-available/000-default.conf 
systemctl restart apache2
ip addr
mkdir /opt/scripts
mv archivos_consigna/backup_full.sh /opt/scripts/
nano /opt/scripts/backup_full.sh 
crontab -e
cat /proc/partitions > particion
ls
cat particion 
crontab -e
ls
mkdir backups
touch backups/logs
crontab -e
cat backups/logs 
cat backups/logs 
crontab -e
cat backups/logs 
ls /mnt/backup_dir/
cat backups/logs 
clear
cat backups/logs 
cat /etc/os-release 
uname -r
hostnamectl
poweroff
echo asd
exit
