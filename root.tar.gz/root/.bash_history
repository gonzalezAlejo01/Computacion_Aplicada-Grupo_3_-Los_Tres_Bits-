ls
ls -a
clear
nano backup_full.sh 
ls
backup_full.sh /root/backupear
bash backup_full.sh /root/backupear
nano backup_full.sh 
bash backup_full.sh /root/backupear
cd ..
cd ..
nano backup_full.sh 
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/backupear/
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/backupear/
-d /mnt/backup_dir/
bash -d /mnt/backup_dir/
bash /opt/scripts/backup_full.sh /root/backupear/
nano /opt/scripts/backup_full.sh 
ls
cd ..
ls /mnt
ls /mnt/backup_dir/
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/backupear/
bash /opt/scripts/backup_full.sh /root/backupear/
ls /root/backupear/
bash /opt/scripts/backup_full.sh /root/backupear/
nano /opt/scripts/backup_full.sh 
tar -czf /root/backupear/ -C /mnt/backup_dir/
nano /root/backupear/test.txt 
tar -czf /root/backupear/ -C /mnt/backup_dir/
tar -czf /root/backupear/ -C /mnt/backup_dir/asd
tar -czf /mnt/backup_dir/backup.tar.gz /root/backupear 
ls /mnt/backup_dir/
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/backupear/
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/backupear/
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/backupear/
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/backupear/
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/backupear/
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/backupear/
nano /opt/scripts/backup_full.sh 
date +%Y%m%d
bash /opt/scripts/backup_full.sh /root/backupear/
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/backupear/
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/backupear/
nano /opt/scripts/backup_full.sh 
ls /mnt/backup_dir/
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/backupear/
ls /mnt/backup_dir/
ls /proc/filesystems 
ls -l /proc/filesystems 
nano /opt/scripts/backup_full.sh 
cat /etc/network/interfaces
bash /opt/scripts/backup_full.sh /root/backupear/test.txt 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/
cd root/
ls
tar -xvf /mnt/backup_dir/archivos_consigna_bkp_20261026.tar.gz
ls
cd archivos_consigna/
ls
cd ..
mkdir delete this
cd delete/
tar -xvf /mnt/backup_dir/archivos_consigna_bkp_20261026.tar.gz
ls
cd root/
ls
cd archivos_consigna/
ls
nano /opt/scripts/backup_full.sh 
cd ..
cd ..
rm root
rmdir -r root
rmdir root
rm -f root
rmdir -f root/archivos_consigna/
rm -rf root/
ls
cd ..
ls
rm asd
rm backup.tar
cat delete
ls delete
ls
cd de
cd delete/
ls
cd ..
cd descomp/
ls
cd ..
rm -fr descomp/
ls
cd root/
ls
cd ..
rm -rf root/
ls
rm this
rmdir this
clear
ls
cd delete/
ls
tar -xvf /mnt/backup_dir/archivos_consigna_bkp_20261026.tar.gz
l
ls
cd root/
ls
cd ..
bash /opt/scripts/backup_full.sh 
cd ..
ls
bash /opt/scripts/backup_full.sh archivos_consigna/ 
cd archivos_consigna/
ls
cd ..
bash /opt/scripts/backup_full.sh archivos_consigna/
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh archivos_consigna/
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh archivos_consigna/
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh archivos_consigna/
ls
bash /opt/scripts/backup_full.sh archivos_consigna
bash /opt/scripts/backup_full.sh /archivos_consigna
bash /opt/scripts/backup_full.sh ./archivos_consigna
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh ./archivos_consigna
bash /opt/scripts/backup_full.sh -help
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh ./archivos_consigna
bash /opt/scripts/backup_full.sh archivos_consigna
nano /opt/scripts/backup_full.sh 
tar -czf /mnt/backup_dir/ -C 
cat /etc/apt/sources.list
nano /etc/apt/sources.list
bash /opt/scripts/backup_full.sh archivos_consigna
cd ..
cd ..
cd /mnt/www_dir/
ls
 nano /etc/apache2/apache2.conf
 nano /etc/apache2/sites-available/000-default.conf 
cat /etc/network/interfaces
lsblk
fdisk sdc
fdisk /dev/sdc
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/
cd ..
cd ..
bash /opt/scripts/backup_full.sh /root/archivos_consigna/
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/
bash /opt/scripts/backup_full.sh /root/archivos_consigna
cd /mnt/backup_dir/
ls
rm backupear_bkp_20261026.tar.gz 
rm _bkp_20261026.tar.gz 
bash /opt/scripts/backup_full.sh /root/archivos_consigna
ls
tar -xvf archivos_consigna_bkp_20261026.tar.gz
ls
cd root/
ls
cd archivos_consigna/
ls
cd ..
cd ..
rm -rf root/
rf archivos_consigna_bkp_20261026.tar.gz 
rm backup.tar.gz 
rm archivos_consigna_bkp_20261026.tar.gz 
nano /opt/scripts/backup_full.sh 

nano /opt/scripts/backup_full.sh 
ls
cd ..
cd ..
bash opt/scripts/backup_full.sh root/archivos_consigna/
ls /mnt/backup_dir/
tar -xvf /mnt/backup_dir/archivos_consigna_bkp_20261026.tar.gz
tar -xvf /mnt/backup_dir/archivos_consigna_bkp_20261028.tar.gz
ls
ls /mnt/backup_dir/
ls
cd root
ls
cd archivos_consigna/
ls
cd ..
cd ..
cd root
ls
mkdir tests_backups
cd tests_backups/
tar -xvf /mnt/backup_dir/archivos_consigna_bkp_20261028.tar.gz
ls
cd root/
cd archivos_consigna/
ls
c d..
cd ..
cd ..
rm -rf root/
ls
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh ../archivos_consigna/ 
bash /opt/scripts/backup_full.sh ../archivos_consigna/ .
bash /opt/scripts/backup_full.sh ../archivos_consigna/.
bash /opt/scripts/backup_full.sh ../archivos_consigna
ls
ls
ls /mnt/backup_dir/
bash /opt/scripts/backup_full.sh ../archivos_consigna/.
ls /mnt/backup_dir/
bash /opt/scripts/backup_full.sh ../archivos_consigna/.
bash /opt/scripts/backup_full.sh ../archivos_consigna/
ls /mnt/backup_dir/
bash /opt/scripts/backup_full.sh /root/archivos_consigna/
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/
bash /opt/scripts/backup_full.sh /root/archivos_consigna
bash /opt/scripts/backup_full.sh /root/archivos_consigna/
clear
bash /opt/scripts/backup_full.sh /root/archivos_consigna/
bash /opt/scripts/backup_full.sh /root/archivos_consigna/
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/
rm /mnt/backup_dir/archivos_consigna_bkp_20261028.tar.gz 
rm /mnt/backup_dir/._bkp_20261028.tar.gz 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/
tar -xzf /mnt/backup_dir/archivos_consigna_bkp_20261028.tar.gz 
ls
ls
cd ..
ls
cd ..
ls
cd ..
tar -xvf /mnt/backup_dir/archivos_consigna_bkp_20261028.tar.gz -C root/tests_backups/
cd root/tests_backups/
ls
rm db.sql 
rm index.php 
tar -xvf /mnt/backup_dir/archivos_consigna_bkp_20261028.tar.gz -C root/tests_backups/
tar -xvf /mnt/backup_dir/archivos_consigna_bkp_20261028.tar.gz -C /root/tests_backups/
ls
nano /opt/scripts/backup_full.sh 
ls /mnt/backup_dir/
rm /mnt/backup_dir/archivos_consigna_bkp_20261028.tar.gz 
ls
rm db.sql 
rm index.php 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/
tar -xvf /mnt/backup_dir/archivos_consigna_bkp_20261028.tar.gz 
ls
cd ..
cd tests_backups/
rm /mnt/backup_dir/archivos_consigna_bkp_20261028.tar.gz 
rm index.php 
rm db.sql 
nano /opt/scripts/backup_full.sh 
mkdir /mnt/backup_dir/asd
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ /asd
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ asd
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ asd
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ asd
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ asd
ls /mnt/backup_dir/
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ asd
rm /mnt/backup_dir/asdarchivos_consigna_bkp_20261028.tar.gz 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ asd
rm /mnt/backup_dir/asdarchivos_consigna_bkp_20261028.tar.gz 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ /asd
rm /mnt/backup_dir//asdarchivos_consigna_bkp_20261028.tar.gz 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ asd/
ls /mnt/backup_dir/
ls /mnt/backup_dir/asd/
rm /mnt/backup_dir/asd/archivos_consigna_bkp_20261028.tar.gz 
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ asd
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ asd
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ asd
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ asd
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ asd
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ asd
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ asd
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ asd
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ asd/
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ /asd/
nano /opt/scripts/backup_full.sh 
ls /mnt/backup_dir/
rm /mnt/backup_dir/asdarchivos_consigna_bkp_20261028.tar.gz 
rm /mnt/backup_dir/asd/archivos_consigna_bkp_20261028.tar.gz 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ /asd/
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ asd/
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ asd
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ a
tar -xvf /mnt/backup_dir/archivos_consigna_bkp_20261028.tar.gz 
ls
rm db.sql 
rm index.php 
tar -xvf /mnt/backup_dir/archivos_consigna_bkp_20261028.tar.gz 
rm db.sql 
rm index.php 
tar -xvf /mnt/backup_dir/asd/archivos_consigna_bkp_20261028.tar.gz 
ls
cd ..
rm -rf tests_backups/
ls
ls backupear/
rm -rf backupear/
rm -rf delete
rm /mnt/backup_dir/archivos_consigna_bkp_20261028.tar.gz 
rm -rf /mnt/backup_dir/asd/
ls /mnt/backup_dir/
cd ..
ls /etc/apt/sources.list
cat /etc/apt/sources.list
nano /opt/scripts/backup_full.sh 
systemctl status cron
clera
clear
cd ..
crontab -e
ls /etc/crontab 
cat /etc/crontab 
cat /etc/cron.d/anacron
cd /etc/cron.d
ls
nano anacron
nano e2scrub_all 
nano php
nano backups
systemctl restart cron
ls /mnt/backup_dir/
bash /opt/scripts/backup_full.sh /var/log
ls /mnt/backup_dir/
rm /mnt/backup_dir/log_bkp_20261028.tar.gz 
nano backups
nano backups
systemctl restart cron
ls /mnt/backup_dir/
nano backups
ls /var/log
nano backups
grep CRON /var/log/syslog | grep backup_full
bash /opt/scripts/backup_full.sh /var/log
cd /root/
mkdir delete
cd delete/
tar -xvf /mnt/backup_dir/log_bkp_20261028.tar.gz 
ls
cd ..
rm -rf delete/
rm /mnt/backup_dir/log_bkp_20261028.tar.gz 
rm /mnt/backup_dir/www_dir_bkp_20261028.tar.gz 
nano /etc/cron.d/backups
ls /mnt/backup_dir/
nano /etc/cron.d/backups
systemctl restart cron
ls /mnt/backup_dir/
grep 'backup_full.sh' /var/log/syslog
nano /etc/cron.d/backups
rm /mnt/backup_dir/www_dir_bkp_20261028.tar.gz 
ls /mnt/backup_dir/lost+found/
ls /mnt/backup_dir
ls -l /mnt/backup_dir/
ls -la /mnt/backup_dir/
ls -a /mnt/backup_dir/
ls /mnt/backup_dir/
nano /etc/cron.d/backups
rm /mnt/backup_dir/www_dir_bkp_20261028.tar.gz 
ls /mnt/backup_dir/
nano /etc/cron.d/backups
cat /tmp/backup-varlog.log 
nano /opt/scripts/backup_full.sh 
nano /etc/cron.d/backups
cat /tmp/backup-varlog.log 
cat /tmp/backup-varlog.log 
ls /mnt/backup_dir/
nano /opt/scripts/backup_full.sh 
nano /etc/cron.d/backups
rm /mnt/backup_dir/www_dir_bkp_20261028.tar.gz 
ls /mnt/backup_dir/
cat /tmp/backup-varlog.log 
rm /tmp/backup-varlog.log 
nano /etc/cron.d/backups
cat /tmp/backup-varlog.log 
cat /tmp/backup-varlog.log 
cat /tmp/backup-varlog.log 
cat /tmp/backup-varlog.log 
nano /opt/scripts/backup_full.sh 
nano /etc/cron.d/backups
ls /mnt/backup_dir/
cat /tmp/backup-varlog.log 
nano /opt/scripts/backup_full.sh 
nano /etc/cron.d/backups
cat /tmp/backup-varlog.log 
nano /etc/cron.d/backups
cat /tmp/backup-varlog.log 
nano /opt/scripts/backup_full.sh 
cat /tmp/backup-varlog.log 
nano /opt/scripts/backup_full.sh 
nano /etc/cron.d/backups
cat /tmp/backup-varlog.log 
nano /etc/cron.d/backups
ls /mnt/backup_dir/
rm /mnt/backup_dir/log_bkp_20261028.tar.gz 
rm /mnt/backup_dir/www_dir_bkp_20261028.tar.gz 
nano /opt/scripts/backup_full.sh 
ls /mnt/backup_dir/
mkdir borrame
cd borrame/
tar -xvf /mnt/backup_dir/log_bkp_20261028.tar.gz 
ls
tar -xvf /mnt/backup_dir/log_bkp_20261028.tar.gz /logs
mkdir /logs
tar -xvf /mnt/backup_dir/log_bkp_20261028.tar.gz /logs
tar -xvf /mnt/backup_dir/log_bkp_20261028.tar.gz ./logs
tar -xvf /mnt/backup_dir/log_bkp_20261028.tar.gz ./logs/
tar -xvf /mnt/backup_dir/log_bkp_20261028.tar.gz -C /logs
ls /l
ls /logs
cd ..
rm -rf borrame/
nano /etc/cron.d/backups
cd ..
cd root
ls
cat /etc/hostname
cat /etc/hosts
ls /root/.ssh/
cat /root/.ssh/authorized_keys 
rm /mnt/backup_dir/archivos_consigna_bkp_20261028.tar.gz 
ip -a
ip a
nano /etc/ssh/sshd_config
ls /var/www/html/
cat /etc/networks 
cat /etc/network/interfaces
systemctl restart network.services
systemctl restart network.services
systemctl restart network.service
systemctl restart networking.service
lsblk
nano /etc/fstab 
nano /etc/apache2/apache2.conf 
nano /etc/apache2/sites-available/default-ssl.conf 
nano /etc/apache2/sites-available/000-default.conf 
nano /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ 
bash /opt/scripts/backup_full.sh /root/archivos_consigna/ asdasd
nano /opt/scripts/backup_full.sh 
ls /mnt/backup_dir/
rm /mnt/backup_dir/archivos_consigna_bkp_20261030.tar.gz 
cat /etc/cron.d/backups 
du -sh /var
ls
cd archivos_consigna/
ls
cd ..
