#!/bin/bash

if [[ "$1" == "-help" || "$1" == "--help" ]]; then
	echo "El script permite generar archivos comprimidos de directorios, y almacenarlos dentro del directorio /backup_dir"
	echo "Como parametros, debe especificarse el directorio a respaldar, y opcionalmente la ubicacion destino dentro de /backup_dir"
	echo "Uso: $0 <origen> [destino]"
	echo "Ejemplo: $0 /var/log"
	echo "Si no se aclara destino, se usa /backup_dir/ por defecto"
	exit 0
elif [[ $# -lt 1 || $# -gt 2 ]]; then
	echo "Error: Cantidad de argumentos incorrecta"
	echo "Use la opción -help para ver el uso correcto"
	exit 1
fi

origen="$1"
destino=""

if [[ $2 != /* ]]; then
	destino="/mnt/backup_dir/$2"
else
	destino="/mnt/backup_dir$2"
fi

if [[ ! -d "$origen" ]]; then
	echo "Error: No se encuentra el directorio de origen"
	exit 1
elif [[ ! -d "$destino" ]]; then
echo "Error: No se encuentra el directorio destino"
	exit 1
elif ! mountpoint -q /mnt/backup_dir; then
	echo "Error: El directorio destino no esta montado"
	exit 1
elif [[ ! -r "$origen" || ! -x "$origen" ]]; then
	echo "Error: No se tienen los permisos necesarios (lectura/ejecucion) sobre el directorio origen"
	exit 1
elif [[ ! -w "$destino" ]]; then
	echo "Error: No se tiene permiso de escritura sobre el destino"
	exit 1
fi

fecha=$(date +%Y%m%d)
nombre=$(basename "$origen")

if [[ "$destino" != */ ]]; then
	destino+="/"
fi

archivo="${destino}${nombre}_bkp_${fecha}.tar.gz"

tar -czf "$archivo" -C "$origen" "." #&>/dev/null;
codEjecucion=$?

if [[ "$codEjecucion" -eq 0 ]];then #&>/dev/null
	echo "Backup realizado correctamente"
	echo "Archivo guardado en: $archivo"
elif [[ "$codEjecucion" -eq 1 ]];then
	echo "Se realiza el respaldo, pero algunos archivos pueden ser inconsistentes"
	echo "Archivo guardado en: $archivo"
else
	echo "Error: No se pudo realizar el backup"
	rm -f "$archivo"
	exit 1
fi

exit 0
